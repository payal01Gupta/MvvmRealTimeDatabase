package com.vpn.myapplicationone.viewmodel;

import android.app.Application;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.vpn.myapplicationone.model.User;
import com.vpn.myapplicationone.ui.repositories.UserRepository;

import java.util.List;

public class UserViewModel extends AndroidViewModel {
    private UserRepository repository;

    private  MutableLiveData<Boolean> _isShowToast = new MutableLiveData<>();
    public LiveData<Boolean> getIsShowLoader() {
        return _isShowToast;
    }
    private MutableLiveData<List<User>> _userList = new MutableLiveData<>();
    public LiveData<List<User>> getUserList(){
        return _userList;
    }

    private MutableLiveData<Boolean> _isLoading = new MutableLiveData<>();

    public LiveData<Boolean> getIsLoading(){
        return _isLoading;
    }
    public UserViewModel(@NonNull Application app) {
        super(app);
        repository = new UserRepository(app);
    }

    public void insert(User user) {
        _isLoading.postValue(true);
        long isInsert=repository.insert(user);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(isInsert!=-1){
                    List<User> userList =  repository.getUsers();
                    _userList.postValue(userList);
                }else{
                    _isShowToast.postValue(true);
                }
                _isLoading.postValue(false);
            }
        },6000);
    }

//    public void update(User user) {
//        repository.update(user);
//        loadUsers();
//    }
}
